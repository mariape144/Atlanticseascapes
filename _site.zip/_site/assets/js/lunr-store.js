var store = [{  
"title": "Ordenanza de corso dictada por Bolívar","date": "1817-03-07","creator": "Secretaría de Relaciones Exteriores","description": "Reformas a la ordenanza de corso creada por Bolíva","subject": "Corso;Ordenanza;Relaciones Exteriores","location": "Colombia", 
"id": "agn_sr_gym_323_77_136"

},{  
"title": "Comunicaciones de Brion desde Santa Marta al Ministerio de Guerra y Marina","date": "1820","creator": "Louis Brion","description": "Comunicaciones de Louis Brion desde Santa Marta al Ministerio de Guerra y Marina. Contiene información sobre diversos temas: entradas y salidas de buques, corsarios, el comandante Aury.","subject": "Corso;Buques;Relaciones Exteriores","location": "Santa Marta, Colombia", 
"id": "agn_sr_gym_328_88_171"

},{  
"title": "Comunicaciones del comandante Louis Brion al ministro de guerra y marinasobre construcción de lanchas cañoneras y aumento de fuerza marítima.","date": "1821-01-29","creator": "Louis Brion","description": "Comunicaciones del comandante Louis Brion al Ministro de Marina sobre construcción de lanchas cañoneras y aumento de fuerza marítima. Nombre de embarcaciones y sus tripulaciones, armamento, matrícula de perscadores.","subject": "Embarcaciones;Armamento;Matrícula de mar","location": "Santa Marta, Colombia", 
"id": "agn_sr_gym_328_161_201"

},{  
"title": "Cuadros de entradas y salidas de buques de Sabanilla remitidas por el capitán del puerto de Sabanilla y comandante de la bahía al Ministerio de Marina","date": "1821","creator": "Capitán del puerto de Sabanilla y comandante de la bahía","description": "Cuadros de entradas y salidas de buques de Sabanilla remitidas por el capitán del puerto de Sabanilla y comandante de la bahía al Ministerio de Marina. Contiene información de nombres y tipos de buques.","subject": "Buques;Entradas y salidas","location": "Sabanilla, Colombia", 
"id": "agn_sr_gym_329_686_702"

},{  
"title": "Información de corsarios y presas de corso de los departamentos de marina de Maracaibo y Margarita remitidos al Comandante General de Marina y el Ministerio de Marina. Comunicaciones de la comandancia general de marina del primer departamento de Marina (Puerto Cabello)","date": "1828","creator": "Comandancia del departamento de Marina de Puerto Cabello","description": "Registro de corsarios en el departamento de marina de Maracaibo desde 1822-1828 y testimonios de presas. Documentos del archivo de Margarita relativo al armamento de corsarios. Comunicaciones del primer departamento de marina (Puerto Cabello) a la Secretaría de Estado y del Despacho de Marina","subject": "Corso;Embarcaciones;Capitanes;Patentes","location": "Maracaibo, Venezuela", 
"id": "agn_sr_gym_339_435_497"

},{  
"title": "Cuadros de entradas y salidas de buques de Venezuela al Ministerio de Marina","date": "1823","creator": "Comandancia de Marina de Maracaibo","description": "Cuadros de entradas y salidas de buques de Puerto de la Vela, Zulia, Guaira.","subject": "Entradas y salidas;Embarcaciones","location": "Zulia, Venezuela", 
"id": "agn_sr_gym_344_264_337"

},{  
"title": "Estados de entradas y salidas de buques del tercer departamento de Marina.","date": "1823","creator": "Comandancia de marina del tercer departamento","description": "Estados de entradas y salidas de buques del tercer departamento de Marina. Santa Marta, Cartagena, Riohacha, Portobelo. Cuadros de estado de los buques de guerra.","subject": "Embarcaciones;Entradas y salidas","location": "Cartagena", 
"id": "agn_sr_gym_344_339_452"

},{  
"title": "Testimonio del expediente sobre el trasbordo de varios efectos pertenecientes a españoles del bergantín inglés Ugie a la goleta corsario General Santander","date": "1823","creator": "Comandancia de Marina (2 departamento)","description": "Testimonio del expediente sobre el trasbordo de varios efectos pertenecientes a españoles del bergantín inglés Ugie a la goleta corsario General Santander. Eran mercancías de comerciantes españoles que transportaba el bergantín.","subject": "Corso;Comercio","location": "Guayra", 
"id": "agn_sr_gym_344_621_669"

},{  
"title": "Testimonio de presa de corso del bergantín María Dolores capturado por el bergantín corsario El Águila.","date": "1823","creator": "Comandancia de marina del segundo departamento","description": "Testimonio del expediente en que el señor Juan Carlos King solicitó se declarase buena presa el bergantín español María dolores capturado por el bergantín corsario el Águila, cuyo buque y carga está retenido por la Aduana de la isla de Barbada","subject": "Corso;Comercio;Presa","location": "Guayra", 
"id": "agn_sr_gym_344_670_702"

},{  
"title": "Testimonio del expediente de presa de la goleta española Dolores por la goleta corsario Ninfa","date": "1823","creator": "Comandancia de marina del segundo departamento","description": "Testimonio del expediente de presa de la goleta española Dolores por la goleta corsario Ninfa","subject": "Corso;Comercio;Presa","location": "Guayra", 
"id": "agn_sr_gym_344_703_725"

},{  
"title": "Testimonio del expediente de presa del bergantín español Nuestra Señora del Rosario por la goleta corsario General Santander.","date": "1823","creator": "Comandancia de marina del segundo departamento","description": "Testimonio del expediente de presa del bergantín español Nuestra Señora del Rosario por la goleta corsario General Santander.","subject": "Corso;Comercio;Presa","location": "Guayra", 
"id": "agn_sr_gym_344_799_847"

},{  
"title": "Testimonio del expediente sobre el apresamiento y condena de buena presa del bergantín español Diana capturado por el bergantín corsario Águila","date": "1823","creator": "Comandancia de marina del segundo departamento","description": "Testimonio del expediente sobre el apresamiento y condena de buena presa del bergantín español Diana capturado por el bergantín corsario Águila","subject": "Corso;Comercio;Presa","location": "Guayra", 
"id": "agn_sr_gym_344_848_898"

},{  
"title": "Testimonio del expediente sobre el represamiento del falucho nacional Rosario por la corbeta de guerra Bolívar","date": "1823","creator": "Comandancia de marina del segundo departamento","description": "Testimonio del expediente sobre el represamiento del falucho nacional Rosario por la corbeta de guerra Bolívar","subject": "Corso;Comercio;Presa","location": "Guayra", 
"id": "agn_sr_gym_344_899_908"

},{  
"title": "Testimonio del expediente sobre el apresamiento de la goleta española la María Antonia por la goleta corsario particular de la república La Centella.","date": "1823","creator": "Comandancia de marina del segundo departamento","description": "Testimonio del expediente sobre el represamiento del falucho nacional Rosario por la corbeta de guerra Bolívar","subject": "Corso;Comercio;Presa","location": "Guayra", 
"id": "agn_sr_gym_344_909_932"

},{  
"title": "1800. Cartagena. Punta Canoa hasta el Castillo de San José","date": "1800","description": "Cartagena: Mapa de la costa, desde Punta Canoa haste el Castillo de San José con los accidentes de la misma, las construcciones y las profundidades litorales.","subject": "Mapa","location": "Cartagena", 
"id": "agn_smp_4_80a"

}];
